#!/bin/bash

java -Xmx3800M -cp bin main.Main --nogui $@