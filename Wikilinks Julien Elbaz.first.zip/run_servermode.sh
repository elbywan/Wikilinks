#!/bin/bash

java -server -Xmx3800M -cp bin main.Main $@