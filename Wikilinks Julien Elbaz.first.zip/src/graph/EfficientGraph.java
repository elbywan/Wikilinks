package graph;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

import utils.Toolz;

public class EfficientGraph {

	private int[][][] graph;
	File f;
	File f2;
	
	public EfficientGraph(String index_path, String dump_path){
		f = new File(index_path);
		f2 = new File(dump_path);
	}
	
	public void buildGraph(){
		
		int length = 0;

		try {
			BufferedReader r = new BufferedReader(new FileReader(f),4096);
			while(r.readLine() != null)
				length++;
			r.close();


			graph = new int[length][][];
			for(int z = 0; z < graph.length; z++){
				graph[z] = new int[2][];
				graph[z][1] = new int[1];
			}
			
			int number;
			String s;

			Toolz.debug_println("======================");

			r = new BufferedReader(new FileReader(f2),4096);
			number = 0;

			while((s = r.readLine()) != null){
				number++;
				if(number%50000 == 0)
					Toolz.debug_println(number);
				//System.out.println(s);

				String[] splitted = s.split("[|]");
				int src = Integer.parseInt(splitted[0]);
				graph[src][0] = new int[splitted.length-1];

				for(int i = 1; i < splitted.length; i++){
					int dest = Integer.parseInt(splitted[i]);
					if(src != dest){
						graph[src][0][i-1] = dest;
						graph[dest][1][graph[dest][1].length-1] = src;
						graph[dest][1] = Arrays.copyOf(graph[dest][1], graph[dest][1].length+1);
					}
				}

			}
			
			r.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public int[] get_outgoing(int node){
		return graph[node][0];
	}
	
	public int[] get_incoming(int node){
		return Arrays.copyOf(graph[node][1], graph[node][1].length-1);
	}
	
	public int[] get_allvertice(int node){
		int[] result = Toolz.merge(get_incoming(node), get_outgoing(node));
		return result;
	}
	
	public int[] LDistance(int starting_node, int distance){
		int[] result = new int[1];
		result[0] = starting_node;
		
		for(int i : get_incoming(starting_node)){
			int pos = -1;
			for(int j = 0; j < get_outgoing(i).length; j++){
				if(get_outgoing(i)[j] == starting_node){
					if(pos == -1){
						for(pos = Math.max(0, j-distance); pos < j; pos++){
							result = Arrays.copyOf(result, result.length+1);
							result[result.length-1] = get_outgoing(i)[pos];
						}
						pos = j+1;
					} else {
						for(int old_pos = pos; pos < j && pos < old_pos + distance; pos++){
							result = Arrays.copyOf(result, result.length+1);
							result[result.length-1] = get_outgoing(i)[pos];
						}
						pos = Math.max(pos,j-distance);
						for(; pos < j; pos++){
							result = Arrays.copyOf(result, result.length+1);
							result[result.length-1] = get_outgoing(i)[pos];
						}
						pos++;
					}
				}
			}
			if(pos != -1){
				for(int old_pos = pos; pos < get_outgoing(i).length && pos < old_pos + distance; pos++){
					result = Arrays.copyOf(result, result.length+1);
					result[result.length-1] = get_outgoing(i)[pos];
				}
			}
		}
		
		Arrays.sort(result);
		
		return result;
	}
	
	private int[] sumOfEdges(int node, int distance){
		int[] edges = get_allvertice(node);
		if(distance == 1)
			return edges;
		for(int e : edges){
			edges = Toolz.merge(edges, sumOfEdges(e,distance-1));
		}
		return edges;
	}
	
	public int[] PDistance(int starting_node, int distance){
		return sumOfEdges(starting_node,distance);
	}
	
	
}
