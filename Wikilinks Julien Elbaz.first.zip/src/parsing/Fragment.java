package parsing;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Set;
import java.util.TreeSet;

import utils.HashMapLowerCase;
import utils.Toolz;

public class Fragment {

	public static void fragmentFile(String input_path, String index_path, String trimmed_path) throws FileNotFoundException,IOException{
		
		File f = new File(input_path);
		File f2 = new File(trimmed_path);
		File f3 = new File(index_path);

		if(f3.exists())
			f3.delete();
		f3.createNewFile();

		BufferedReader r = new BufferedReader(new FileReader(f),4096);
		BufferedWriter w = new BufferedWriter(new FileWriter(f3),4096);	

		HashMapLowerCase map = new HashMapLowerCase();
		String s;
		int number = 0;
		int max_index = 0;
		StringBuilder builder;

		while((s = r.readLine()) != null){
			number++;
			if(number%50000 == 0)
				Toolz.debug_println(number);

			builder = new StringBuilder();
			String[] splitted = s.split("[|]");
			if(!map.containsKey(splitted[0])){
				map.put(splitted[0], max_index);
				builder.append(Integer.toString(max_index)); builder.append("|");
				builder.append(splitted[0].toLowerCase().trim());  builder.append("\n");
				w.write(builder.toString());
				max_index++;
			}
			for(int i = 1; i < splitted.length; i++){
				if(!map.containsKey(splitted[i])){
					builder = new StringBuilder();
					map.put(splitted[i], max_index);
					builder.append(Integer.toString(max_index)); builder.append("|");
					builder.append(splitted[i].toLowerCase().trim()); builder.append("\n");
					w.write(builder.toString());
					max_index++;
				}
			}
		}

		r.close();
		w.close();

		Toolz.debug_println("=========");

		if(f2.exists())
			f2.delete();
		f2.createNewFile();
		r = new BufferedReader(new FileReader(f),4096);
		w = new BufferedWriter(new FileWriter(f2),4096);
		number = 0;

		while((s = r.readLine()) != null){
			number++;
			if(number%50000 == 0)
				Toolz.debug_println(number);

			String[] splitted = s.split("[|]");
			w.write(map.get(splitted[0]).toString());
			for(int i = 1; i < splitted.length; i++){
				w.write("|");
				w.write(map.get(splitted[i]).toString());
			}
			w.write("\n");
		}
		r.close();
		w.close();

		map.clear();
		map = null;

		Toolz.debug_println("=========");

	}
	
	public static int getId(String title, String index_path) throws IOException{
		
		File f = new File(index_path);
		BufferedReader r = new BufferedReader(new FileReader(f),4096);
		String s;
		
		while((s = r.readLine()) != null){
			String[] splitted = s.split("[|]");
			if(splitted[1].compareToIgnoreCase(title.trim()) == 0)
				return Integer.parseInt(splitted[0]);
		}
		
		return -1; 
	}
	
	public static String getTitle(int id, String index_path) throws IOException{
		
		File f = new File(index_path);
		BufferedReader r = new BufferedReader(new FileReader(f),4096);
		String s;
		
		while((s = r.readLine()) != null){
			String[] splitted = s.split("[|]");
			if(Integer.parseInt(splitted[0]) == id)
				return splitted[1];
		}
		
		return ""; 
	}
	
	public static String[] getTitle(int[] list, String index_path) throws IOException{
		
		File f = new File(index_path);
		BufferedReader r = new BufferedReader(new FileReader(f),4096);
		String s;
		String[] result = new String[list.length];
		Set<Integer> set = new TreeSet<Integer>();
		for(int i : list)
			set.add(new Integer(i));
		
		while((s = r.readLine()) != null){
			String[] splitted = s.split("[|]");
			if(set.contains(Integer.parseInt(splitted[0])))
			for(int i = 0; i < list.length; i++){
				if(Integer.parseInt(splitted[0]) == list[i])
					result[i] = splitted[1];
			}
			
		}
		
		set.clear();
		set = null;
		
		return result; 
	}
	
}
