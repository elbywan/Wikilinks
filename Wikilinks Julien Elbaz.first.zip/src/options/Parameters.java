package options;

public class Parameters {

	public static boolean	 	debug				= false;
	
	public static String 		file_firstStep		= "Test Files/graph_output.txt";
	public static String 		file_Index			= "Test Files/graph_output_index.txt";
	public static String 		file_Trimmed		= "Test Files/graph_output_integers.txt";
	public static String		file_Content		= "Test Files/frwiki-latest-pages-articles.xml";
	
	public static String 		input_Requests		= "Test Files/requetes-10.txt";
	public static String 		output_Responses	= "Test Files/reponses-10.txt";
	
	public static int 			parse_nbThreads 		= 6;
	public static int 			parse_maxPages 			=-1;
	public static int 			parse_PPT				= 2;
	public static int 			parse_capacity	 		= 2000;
	
	
	
	
	
}
